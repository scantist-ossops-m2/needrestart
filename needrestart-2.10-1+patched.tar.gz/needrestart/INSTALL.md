Prerequisites
=============

Perl
----

- Module::Find
- Module::ScanDeps
- Locale::TextDomain
- Proc::ProcessTable
- Sort::Naturally
- Term::ReadKey
- Parent (for legacy Perl versions, i.e. on CentOS 6)

Misc
----

- gettext
- po-debconf (on Debian derivates)
- xz-utils
